#!/bin/bash
echo "Iniciando PyCheatEngine..."
python3 PyCheatEngine.py
